var annotated_dup =
[
    [ "pid_cfg_t", "structpid__cfg__t.html", "structpid__cfg__t" ],
    [ "pid_in_t", "structpid__in__t.html", "structpid__in__t" ],
    [ "pid_out_t", "structpid__out__t.html", "structpid__out__t" ],
    [ "pid_s", "structpid__s.html", "structpid__s" ]
];