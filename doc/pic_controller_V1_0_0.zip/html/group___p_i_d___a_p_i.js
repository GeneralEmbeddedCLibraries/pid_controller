var group___p_i_d___a_p_i =
[
    [ "pid_cfg_t", "structpid__cfg__t.html", [
      [ "kd", "structpid__cfg__t.html#a982d63e4eaf74ba75749add48a62f9d6", null ],
      [ "ki", "structpid__cfg__t.html#a88c37cc0013a192de782626e5d54ed6a", null ],
      [ "kp", "structpid__cfg__t.html#af794c44f0d79a5594cb0115df78d73d0", null ],
      [ "lpf_d_fc", "structpid__cfg__t.html#a78801c1d900a9607709812c03e554035", null ],
      [ "max", "structpid__cfg__t.html#a8db6cdfb0cb112664cb83841f249b549", null ],
      [ "min", "structpid__cfg__t.html#aea386ff82edc8d629d7ae0c54e7c9164", null ],
      [ "ts", "structpid__cfg__t.html#a2fe26aa81eb3377a417a7ebd8054b142", null ],
      [ "windup_k", "structpid__cfg__t.html#a23b4d42d01b7192d06450900428524c7", null ]
    ] ],
    [ "pid_in_t", "structpid__in__t.html", [
      [ "act", "structpid__in__t.html#af9e44febc6dc9327d1d29c7e62d61f12", null ],
      [ "ff", "structpid__in__t.html#ae9c1f2ef1fa44bca1eb2a19b5cc5046e", null ],
      [ "ref", "structpid__in__t.html#a33bb2797a4e6b83321b4430606d068c6", null ]
    ] ],
    [ "pid_out_t", "structpid__out__t.html", [
      [ "d_part", "structpid__out__t.html#aa8c21da8f5492b49f47081abdd918aa9", null ],
      [ "err", "structpid__out__t.html#a703159d1955014b24e1a231017e99fa8", null ],
      [ "i_part", "structpid__out__t.html#aabdb4f1c2040ca9708909a6c1584ffab", null ],
      [ "out", "structpid__out__t.html#ad0357d21b4d91a30d2d0c1194be32cee", null ],
      [ "p_part", "structpid__out__t.html#a8470d8cbb42ad4a2e4458dbaef02449e", null ]
    ] ],
    [ "PID_VER_DEVELOP", "group___p_i_d___a_p_i.html#ga995fefb3648602536cd14aaac24dc2ea", null ],
    [ "PID_VER_MAJOR", "group___p_i_d___a_p_i.html#ga481fa09bc493d7bf871d3c380851ed47", null ],
    [ "PID_VER_MINOR", "group___p_i_d___a_p_i.html#gaac2f834fe3c8ebb57a0325c2e7d2a6cf", null ],
    [ "p_pid_t", "group___p_i_d___a_p_i.html#gaeade6cdb26bb6a349e02315752258661", null ],
    [ "pid_status_t", "group___p_i_d___a_p_i.html#ga50419de16e268c8585602f884c9c1419", [
      [ "ePID_OK", "group___p_i_d___a_p_i.html#gga50419de16e268c8585602f884c9c1419ad98c46966e80d4532c7088e20c6fca9c", null ],
      [ "ePID_ERROR", "group___p_i_d___a_p_i.html#gga50419de16e268c8585602f884c9c1419ab608e92b4fb9d907405937620acfde40", null ],
      [ "ePID_ERROR_INIT", "group___p_i_d___a_p_i.html#gga50419de16e268c8585602f884c9c1419ab2ce313da5ef1994016ffa3e0c90c826", null ],
      [ "ePID_ERROR_CFG", "group___p_i_d___a_p_i.html#gga50419de16e268c8585602f884c9c1419a9f581a926dc808684a548b864a178147", null ]
    ] ],
    [ "pid_get_cfg", "group___p_i_d___a_p_i.html#ga747bed30de0b38e198800f8af2e5b1e2", null ],
    [ "pid_hndl", "group___p_i_d___a_p_i.html#ga862784f332a6260f0eb693b41d73fcbd", null ],
    [ "pid_init", "group___p_i_d___a_p_i.html#gaac6891076c0f94f42594eb41662e5747", null ],
    [ "pid_is_init", "group___p_i_d___a_p_i.html#ga0063a34ed60ee9e8c0fac64242c46238", null ],
    [ "pid_set_cfg", "group___p_i_d___a_p_i.html#ga49ddf83df560e37a28cd16d6a93d4cea", null ]
];