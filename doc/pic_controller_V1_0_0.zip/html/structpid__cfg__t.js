var structpid__cfg__t =
[
    [ "kd", "structpid__cfg__t.html#a982d63e4eaf74ba75749add48a62f9d6", null ],
    [ "ki", "structpid__cfg__t.html#a88c37cc0013a192de782626e5d54ed6a", null ],
    [ "kp", "structpid__cfg__t.html#af794c44f0d79a5594cb0115df78d73d0", null ],
    [ "lpf_d_fc", "structpid__cfg__t.html#a78801c1d900a9607709812c03e554035", null ],
    [ "max", "structpid__cfg__t.html#a8db6cdfb0cb112664cb83841f249b549", null ],
    [ "min", "structpid__cfg__t.html#aea386ff82edc8d629d7ae0c54e7c9164", null ],
    [ "ts", "structpid__cfg__t.html#a2fe26aa81eb3377a417a7ebd8054b142", null ],
    [ "windup_k", "structpid__cfg__t.html#a23b4d42d01b7192d06450900428524c7", null ]
];